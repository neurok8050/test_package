from setuptools import setup
setup(
    name='test_package_DnD',
    version='0.0.1',
    author='Claudéric',
    description='simple test packaging',
    long_description='a simple test packaging that can be use for DnD',
    url='https://github.com/neurok8050',
    keywords='development, setup, setuptools',
    python_requires='>=3.7, <4'
)
